<?php
namespace App\Config;
require_once __DIR__ . "/../../vendor/autoload.php";
Database::getConnection();