<?php

namespace App\Models\Auth;

class AuthModel
{

}