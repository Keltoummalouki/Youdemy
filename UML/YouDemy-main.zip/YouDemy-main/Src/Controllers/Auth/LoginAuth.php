<?php

namespace App\Controllers\Auth;

class LoginAuth
{

}
namespace App\auth\Controllers;
require_once __DIR__ . '../../../../vendor/autoload.php';

