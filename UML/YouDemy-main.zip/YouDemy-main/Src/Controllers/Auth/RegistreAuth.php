<?php

namespace App\Controllers\Auth;

class RegistreAuth
{

}